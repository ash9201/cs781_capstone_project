# Sources and implementation record

Prepared on 26 October 2026.

## Course and data

- CS781 Capstone.pdf, Phase 5 sections 11.1–11.4: multi-label Legal Statute Identification, all four Phase 1 architecture families, different adaptation methods, compulsory LoRMA and knowledge distillation.
- The experiment plan contains four submissions.
- Official task data: https://huggingface.co/datasets/Exploration-Lab/CS-781-Capstone . Downloads resolve and retain one real repository commit before retrieving Phase_5_LSI/Train/train.json, Train/dev.json and Test/test.json. File SHA-256 hashes are recorded.
- Supplied evaluate_phase5.py, when attached, defines the exact external label-dimension and metric contract. Internal metrics are separately identified until that check is available.

## Methods

- Chalkidis et al. (2019), Large-Scale Multi-Label Text Classification on EU Legislation: https://aclanthology.org/P19-1636/ . Label-wise attention background; our head applies it across inherited Transformer chunk representations.
- Houlsby et al. (2019), Parameter-Efficient Transfer Learning for NLP: https://proceedings.mlr.press/v97/houlsby19a.html . Bottleneck-adapter provenance; actual placement follows the retained pre-norm backbone.
- Bihany, Patel and Modi (2025), LoRMA: https://aclanthology.org/2025.findings-acl.527/ ; additive-identity rank inflation in equation 8: https://arxiv.org/html/2506.07621v1 . The code uses output-side LoRMA+ and supports rectangular FFN matrices.
- Yang et al. (2016), Hierarchical Attention Networks for Document Classification: https://aclanthology.org/N16-1174/ . Hierarchical aggregation context; the exact projection/BiGRU/chunk readouts are project choices.
- Hinton, Vinyals and Dean (2015), Distilling the Knowledge in a Neural Network: https://arxiv.org/abs/1503.02531 . Distillation background. LSI compares independent Bernoulli probabilities, not a softmax across multiple applicable statutes.
- Loshchilov and Hutter, Decoupled Weight Decay Regularization: https://arxiv.org/abs/1711.05101 . AdamW is used for realistic zero-LR optimizer timing and the temporary learning check.

## APIs

- PyTorch BCEWithLogitsLoss: https://docs.pytorch.org/docs/2.11/generated/torch.nn.BCEWithLogitsLoss.html
- PyTorch checkpoint: https://docs.pytorch.org/docs/2.11/checkpoint.html
- PyTorch DataParallel: https://docs.pytorch.org/docs/2.11/generated/torch.nn.DataParallel.html
- PyTorch GRU: https://docs.pytorch.org/docs/2.11/generated/torch.nn.GRU.html
- Hugging Face version-pinned downloads: https://huggingface.co/docs/huggingface_hub/guides/download
- NumPy memory-mapped arrays: https://numpy.org/doc/stable/reference/generated/numpy.memmap.html
- Python ZIP archives: https://docs.python.org/3/library/zipfile.html

## Reused and new code

Native Phase 1 backbones, the original legal BPE algorithm and its utility module are retained from the archived original implementation. The known original checkpoint/tokenizer identities are in src/phase1_reference.json.

Shared readout, adapter, LoRMA+ and manual BiGRU components are retained from the checked Phase 4 code. Phase 5 adds the multi-label head, label mapping, weighted BCE, Bernoulli distillation, task audit, transactional packed cache and bounded probe orchestration.

No pretrained model is downloaded by this package. Hugging Face Hub is used for the official task data only. Model construction loads the original verified Phase 1 checkpoints.

## Evidence boundaries

local_validation.json records small synthetic CPU integration tests. Full data and original full-size checkpoint execution occur in the Kaggle session. Separate runtime reports identify which checks passed, failed, timed out or were not run.

Zero-LR timing initializes AdamW state but preserves parameter values. The short nonzero-LR mechanics check uses a temporary model process; its weights are discarded and are not a trained teacher or submission model.

The prepared cache preserves exact content tokens, rows and labels. Its positive-weight cap, chunk budget, pooling design, learning rates and epoch proposals are project choices. Method citations do not establish those numbers as optimal.

