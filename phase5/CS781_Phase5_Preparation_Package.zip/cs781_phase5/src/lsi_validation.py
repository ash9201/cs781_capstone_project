"""Small mathematical checks independent of the full legal checkpoints."""
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
from common import chunk_spans, selected_spans, coverage
from model_components import LoRMAPlusLinear, Bottleneck, DocumentBiGRU
from lsi_model import weighted_bce, bernoulli_distillation


def run_math_checks():
    torch.manual_seed(19)
    checks = {}
    for size in (1,17,31,32,100,1001):
        spans = chunk_spans(size,32,7)
        assert coverage(size,spans)==1.
        for policy in ("uniform","head","tail","head_tail"):
            selected = selected_spans(size,32,7,4,policy)
            assert len(selected)<=4 and len(set(selected))==len(selected)
            assert all(0<=a<b<=size and b-a<=30 for a,b in selected)
    checks["chunk_bounds_and_full_coverage"] = "passed"
    layer = nn.Linear(5,7,bias=True).double()
    lorma = LoRMAPlusLinear(layer,2,4,0).double()
    x = torch.randn(3,5,dtype=torch.float64,requires_grad=True)
    torch.testing.assert_close(lorma(x),layer(x),rtol=0,atol=0)
    with torch.no_grad():
        lorma.lorma_B.normal_(std=.05)
    effective = layer.weight + lorma.scaling*lorma.lorma_B@lorma.lorma_A@layer.weight
    torch.testing.assert_close(lorma(x),F.linear(x,effective,layer.bias),rtol=1e-12,atol=1e-12)
    assert torch.autograd.gradcheck(lorma,(x,),atol=1e-5)
    checks["lorma_identity_rectangular_matrix_and_gradients"] = "passed"
    adapter = Bottleneck(7,3,0).double()
    values = torch.randn(4,7,dtype=torch.float64)
    torch.testing.assert_close(adapter(values),values,rtol=0,atol=0)
    checks["adapter_identity_initialization"] = "passed"
    manual, reference = DocumentBiGRU(5,3).double(), nn.GRU(5,3,bidirectional=True).double()
    with torch.no_grad():
        for d,suffix in ((0,""),(1,"_reverse")):
            for target,source in (("weight_ih_l0",manual.input[d].weight),
                                  ("bias_ih_l0",manual.input[d].bias),
                                  ("weight_hh_l0",manual.recurrent[d].weight),
                                  ("bias_hh_l0",manual.recurrent[d].bias)):
                getattr(reference,target+suffix).copy_(source)
    seq = torch.randn(6,5,dtype=torch.float64)
    torch.testing.assert_close(manual(seq),reference(seq[:,None])[0][:,0],rtol=1e-12,atol=1e-12)
    checks["manual_bigru_matches_reference"] = "passed"
    logits = torch.tensor([[2.,2.,-2.]],requires_grad=True)
    y = torch.tensor([[1.,1.,0.]])
    loss = weighted_bce(logits,y,torch.ones(3))
    torch.testing.assert_close(loss,F.softplus(torch.tensor(-2.)))
    assert torch.sigmoid(logits)[0,:2].sum()>1
    loss.backward()
    assert torch.isfinite(logits.grad).all()
    checks["independent_sigmoid_multihot_bce_and_gradients"] = "passed"
    student = torch.randn(3,5,requires_grad=True)
    teacher = torch.randn(3,5,requires_grad=True)
    same = bernoulli_distillation(student,student)
    assert abs(float(same))<1e-6
    kd = bernoulli_distillation(student,teacher)
    kd.backward()
    assert teacher.grad is None and torch.isfinite(student.grad).all()
    checks["bernoulli_kd_identity_gradients_and_detached_teacher"] = "passed"
    return {"status":"passed","checks":checks,"synthetic_fixtures_only":True,
            "trained_teacher_cache_created":False}

