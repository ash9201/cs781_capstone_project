"""Bounded model correctness and timing probes; no trained model is exported."""
import argparse
import copy
import gc
import json
import math
import random
import statistics
import time
from pathlib import Path
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
from common import read_json, write_json
from lsi_data import load_cache, training_selection, collate_cases, digest
from lsi_model import load_original, make_classifier, weighted_bce, bernoulli_distillation
from model_components import chunk_states


def seed_all(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def synchronize(device):
    if device.type == "cuda":
        for i in range(min(2, torch.cuda.device_count())):
            torch.cuda.synchronize(i)


def move(batch, device):
    return {k: v.to(device) for k, v in batch.items()}


def runner_for(model):
    if next(model.parameters()).is_cuda and torch.cuda.device_count() >= 2:
        return nn.DataParallel(model, device_ids=[0, 1])
    return model


def optimizer_for(model, architecture, zero_lr=True):
    rates = {"decoder": 5e-6, "encoder_decoder": 1e-4, "prefix": 1e-4, "efficient": 1e-5}
    groups = []
    for is_backbone in (True, False):
        values = [p for n,p in model.named_parameters() if p.requires_grad and n.startswith("lm.") == is_backbone]
        groups.append({"params": values, "lr": 0. if zero_lr else
                       rates[architecture] if is_backbone else 1e-3})
    return torch.optim.AdamW(groups, weight_decay=.01)


@torch.no_grad()
def native_check(original, architecture, device):
    original.eval()
    width = min(13, original.cfg.max_seq_len-1)
    ids = torch.randint(4, original.cfg.vocab_size, (2,width), device=device)
    ids[:,0], ids[:,-1] = 2, 3
    lengths = torch.full((2,),width,device=device,dtype=torch.long)
    _, readout = chunk_states(original, architecture, ids, lengths)
    query = torch.full((2,1),2,device=device,dtype=torch.long)
    expected = original(ids,query,lengths)[:,0] if architecture in ("prefix","encoder_decoder") else original(ids)[:,-2]
    actual = original.head(readout)
    torch.testing.assert_close(actual,expected,rtol=3e-4,atol=3e-5)
    return {"status":"passed","maximum_logit_difference":float((actual-expected).abs().max())}


def small_rows(rows, count=2, tokens=24):
    return [dict(rows[i % len(rows)], token_ids=rows[i % len(rows)]["token_ids"][:tokens])
            for i in range(count)]


@torch.no_grad()
def padding_check(model, rows, labels, geometry, device):
    model.eval()
    old = model.use_amp
    model.use_amp = False
    batch, _ = collate_cases(small_rows(rows), labels, **geometry)
    batch = move(batch,device)
    first = model(**batch)
    altered = {k:v.clone() for k,v in batch.items()}
    allowed = torch.arange(batch["ids"].shape[-1],device=device)[None,None] < batch["lengths"][:,:,None]
    altered["ids"][~allowed] = 5
    expanded = {"ids": F.pad(altered["ids"],(0,3,0,2),value=7),
                "lengths": F.pad(altered["lengths"],(0,2)),
                "positions": F.pad(altered["positions"],(0,0,0,2),value=.75)}
    second = model(**expanded)
    torch.testing.assert_close(first["logits"],second["logits"],rtol=4e-4,atol=4e-5)
    torch.testing.assert_close(first["chunk_attention"].sum(1),
        torch.ones((len(batch["ids"]),len(labels)),device=device))
    assert bool((second["chunk_attention"][:,-2:] == 0).all())
    model.use_amp = old
    return {"status":"passed","padding_invariant":True,"label_attention_normalizes_over_valid_chunks":True}


def parallel_check(model, rows, labels, weights, geometry, device):
    if device.type != "cuda" or torch.cuda.device_count() < 2:
        return {"status":"not_run","reason":"Two CUDA devices unavailable."}
    model.eval()
    previous = model.use_amp
    model.use_amp = False
    batch,y = collate_cases(small_rows(rows),labels,**geometry)
    batch,y = move(batch,device),y.to(device)
    model.zero_grad(set_to_none=True)
    serial = model(**batch)["logits"]
    weighted_bce(serial,y,weights).backward()
    names = ["output_weight","projection.weight"]
    names += [n for n,p in model.named_parameters()
              if n.startswith("lm.") and p.requires_grad and p.grad is not None
              and float(p.grad.abs().max()) > 0][:2]
    reference = {n:p.grad.detach().flatten()[:128].cpu().clone()
                 for n,p in model.named_parameters() if n in names}
    serial = serial.detach()
    model.zero_grad(set_to_none=True)
    parallel = nn.DataParallel(model,device_ids=[0,1])
    result = parallel(**batch)
    assert set(result["device_ids"].cpu().tolist()) == {0,1}
    weighted_bce(result["logits"],y,weights).backward()
    torch.testing.assert_close(serial,result["logits"],rtol=3e-3,atol=2e-4)
    for n,p in model.named_parameters():
        if n in reference:
            torch.testing.assert_close(reference[n],p.grad.detach().flatten()[:128].cpu(),rtol=5e-3,atol=1e-5)
    model.zero_grad(set_to_none=True)
    model.use_amp = previous
    del parallel
    return {"status":"passed","devices":[0,1],"checked_gradient_tensors":names,
            "scope":"FP32 logits and selected gradient slices, dropout disabled"}


def one_update(model, runner, rows, labels, weights, geometry, batch_size, optimizer, scaler, device):
    for retry in range(6):
        optimizer.zero_grad(set_to_none=True)
        model.train()
        total_loss, devices = 0.,set()
        synchronize(device)
        started = time.monotonic()
        for i in range(0,len(rows),batch_size):
            batch,y = collate_cases(rows[i:i+batch_size],labels,**geometry)
            result = runner(**move(batch,device))
            devices.update(result["device_ids"].detach().cpu().tolist())
            loss = weighted_bce(result["logits"],y.to(device),weights,reduction="sum") / (len(rows)*len(labels))
            if not bool(torch.isfinite(loss)):
                raise FloatingPointError("Nonfinite multi-label loss.")
            scaler.scale(loss).backward()
            total_loss += float(loss.detach())
        scaler.unscale_(optimizer)
        norm = torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad],1.)
        if not bool(torch.isfinite(norm)):
            if scaler.is_enabled():
                scaler.update(new_scale=max(1.,scaler.get_scale()/2))
                continue
            raise FloatingPointError("Nonfinite FP32 gradients.")
        bad = [n for n,p in model.named_parameters() if not p.requires_grad and p.grad is not None]
        if bad:
            raise AssertionError("Frozen weights acquired gradients: "+str(bad[:3]))
        backbone_gradient = any(n.startswith("lm.") and p.requires_grad and p.grad is not None
                                and bool((p.grad != 0).any()) for n,p in model.named_parameters())
        if not backbone_gradient:
            raise AssertionError("No nonzero gradient reached the intended backbone adaptation.")
        scaler.step(optimizer)
        scaler.update()
        synchronize(device)
        return {"seconds":time.monotonic()-started,"loss":total_loss,"gradient_norm":float(norm),
                "devices_observed":sorted(devices),"amp_retries":retry}
    raise FloatingPointError("Repeated nonfinite gradients at probe scale.")


def timing_probe(model, architecture, rows, labels, weights, geometry, config, device):
    requested = config["train_batch_cases"]
    candidates = sorted(set([requested]+[b for b in (8,4,2,1) if b < requested]),reverse=True)
    if config["require_two_gpus"]:
        candidates = [b for b in candidates if b >= 2]
    attempts = []
    actual = optimizer = runner = scaler = None
    for physical in candidates:
        try:
            source = rows[0]["token_ids"]
            content = geometry["total_tokens"]-2
            stress = [dict(rows[i % len(rows)], token_ids=np.resize(source,content*geometry["max_chunks"]).astype(np.int32))
                      for i in range(physical)]
            stress_geometry = dict(geometry,overlap=0)
            optimizer = optimizer_for(model,architecture,zero_lr=True)
            scaler = torch.amp.GradScaler("cuda",enabled=device.type=="cuda" and config["amp"])
            model.use_amp = config["amp"]
            runner = runner_for(model)
            if device.type == "cuda":
                for i in range(min(2,torch.cuda.device_count())):
                    torch.cuda.reset_peak_memory_stats(i)
            stress_result = one_update(model,runner,stress,labels,weights,stress_geometry,
                                       physical,optimizer,scaler,device)
            if config["require_two_gpus"] and stress_result["devices_observed"] != [0,1]:
                raise ValueError("The stress batch did not execute on both GPUs.")
            actual = physical
            attempts.append({"batch":physical,"status":"passed"})
            break
        except torch.cuda.OutOfMemoryError:
            attempts.append({"batch":physical,"status":"out_of_memory"})
            model.zero_grad(set_to_none=True)
            optimizer = runner = scaler = None
            gc.collect()
            torch.cuda.empty_cache()
    if actual is None:
        raise RuntimeError("No usable physical batch fitted on the available devices.")
    accumulation = math.ceil(config["target_effective_cases"]/actual)
    effective = actual*accumulation
    rng = np.random.default_rng(config["seed"]+411)
    count = effective*(config["benchmark_updates"]+1)
    indices = np.resize(rng.permutation(len(rows)),count)
    sampled = [rows[int(i)] for i in indices]
    times = []
    for step in range(config["benchmark_updates"]+1):
        group = sampled[step*effective:(step+1)*effective]
        result = one_update(model,runner,group,labels,weights,geometry,actual,optimizer,scaler,device)
        if step > 0:
            times.append(result["seconds"])
        print(f"Timing update {step+1}/{config['benchmark_updates']+1}: {result['seconds']:.2f}s",flush=True)
    model.eval()
    inference_rows = sampled[:max(2*actual,8)]
    synchronize(device)
    started = time.monotonic()
    with torch.no_grad():
        for i in range(0,len(inference_rows),actual):
            batch,_ = collate_cases(inference_rows[i:i+actual],labels,**geometry)
            runner(**move(batch,device))
    synchronize(device)
    inference_seconds = time.monotonic()-started
    memory = [{"device":i,"name":torch.cuda.get_device_name(i),
               "peak_allocated_gib":torch.cuda.max_memory_allocated(i)/2**30,
               "peak_reserved_gib":torch.cuda.max_memory_reserved(i)/2**30}
              for i in range(min(2,torch.cuda.device_count()))] if device.type=="cuda" else []
    model.zero_grad(set_to_none=True)
    del optimizer,scaler,runner
    gc.collect()
    if device.type=="cuda":
        torch.cuda.empty_cache()
    return {"status":"passed","physical_batch":actual,"accumulation_steps":accumulation,
            "effective_cases_per_update":effective,"attempts":attempts,"memory":memory,
            "measured_seconds_per_update":times,"median_seconds_per_update":statistics.median(times),
            "inference_cases":len(inference_rows),"inference_seconds":inference_seconds,
            "inference_seconds_per_case":inference_seconds/len(inference_rows),
            "timing_note":"Zero learning-rate AdamW updates include forward/backward, clipping and optimizer work."}


def temporary_learning(model, architecture, rows, labels, weights, geometry, steps, device):
    for module in model.modules():
        if isinstance(module,nn.Dropout):
            module.p = 0.
        if isinstance(getattr(module,"dropout",None),float):
            module.dropout = 0.
    sample = small_rows(rows,count=min(4,len(rows)),tokens=min(64,geometry["total_tokens"]-2))
    batch,y = collate_cases(sample,labels,**geometry)
    batch,y = move(batch,device),y.to(device)
    model.use_amp = device.type=="cuda"
    optimizer = optimizer_for(model,architecture,zero_lr=False)
    scaler = torch.amp.GradScaler("cuda",enabled=device.type=="cuda")
    @torch.no_grad()
    def evaluation():
        model.eval()
        return float(weighted_bce(model(**batch)["logits"],y,weights))
    before = evaluation()
    model.train()
    for _ in range(steps):
        optimizer.zero_grad(set_to_none=True)
        loss = weighted_bce(model(**batch)["logits"],y,weights)
        scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        norm = torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad],1.)
        if not bool(torch.isfinite(norm)):
            raise FloatingPointError("Nonfinite gradient in temporary learning check.")
        scaler.step(optimizer)
        scaler.update()
    after = evaluation()
    if not math.isfinite(after):
        raise FloatingPointError("Nonfinite temporary-learning result.")
    return {"status":"passed" if after < before else "warning","loss_before":before,"loss_after":after,
            "steps":steps,"cases":len(sample),"temporary_model_only":True,
            "note":"A mechanics check, not an estimate of development accuracy. Probe weights are discarded."}


def run_probe(config):
    seed_all(config["seed"])
    device = torch.device(config.get("device","cuda:0" if torch.cuda.is_available() else "cpu"))
    if config["require_two_gpus"] and (device.type!="cuda" or torch.cuda.device_count()<2):
        raise RuntimeError("Select Kaggle GPU T4 x2, or set RUN_GPU_CHECKS=False for data-only preparation.")
    root = Path(config["project_root"])
    reports = root/"reports"
    labels = read_json(reports/"label_vocabulary.json")["label_ids"]
    loss_settings = read_json(reports/"loss_settings.json")
    rows, identity = load_cache(root/"prepared"/"cache")
    train = training_selection(rows,config["deduplicate_training"])
    geometry = {k:config[k] for k in ("total_tokens","overlap","max_chunks","policy")}
    architecture = config["architecture"]
    print("Loading original Phase 1 checkpoint:",architecture,flush=True)
    original,native = load_original(config["checkpoint_path"],architecture,config["tokenizer_signature"])
    original = original.to(device)
    print("Checking original readout",flush=True)
    native_result = native_check(original,architecture,device)
    if architecture=="efficient":
        original = original.cpu()
    model,counts = make_classifier(original,architecture,labels,loss_settings,config["model_settings"])
    if architecture=="efficient":
        del original
        gc.collect()
    model = model.to(device)
    weights = torch.tensor(loss_settings["positive_weights"],device=device,dtype=torch.float32)
    print("Checking padding and label-wise attention",flush=True)
    padding = padding_check(model,train,labels,geometry,device)
    print("Checking two-device execution",flush=True)
    parallel = parallel_check(model,train,labels,weights,geometry,device)
    print("Measuring full update groups",flush=True)
    timing = timing_probe(model,architecture,train,labels,weights,geometry,config,device)
    print("Checking temporary learning",flush=True)
    learning = temporary_learning(model,architecture,train,labels,weights,geometry,config["temporary_steps"],device)
    validation_unique = len({(r["id"],r["text_sha256"]) for r in rows if r["split"]=="dev"})
    epoch_updates = math.ceil(len(train)/timing["effective_cases_per_update"])
    val_seconds = validation_unique*timing["inference_seconds_per_case"]
    epoch_seconds = epoch_updates*timing["median_seconds_per_update"]
    return {"status":"passed" if learning["status"]=="passed" else "warning",
            "architecture":architecture,"checkpoint_sha256":config["checkpoint_sha256"],
            "request_fingerprint":config["request_fingerprint"],"data_identity":identity,
            "phase1":native,"parameters":counts,"label_columns":len(labels),
            "checks":{"native_readout":native_result,"padding":padding,"two_gpu":parallel,
                      "temporary_learning":learning},"timing":timing,
            "estimates":{"train_epoch_minutes":epoch_seconds/60,
                         "full_validation_minutes":val_seconds/60,
                         "epochs_in_target_budget_with_two_validations_per_epoch":
                           config["target_training_hours"]*3600/(epoch_seconds+2*val_seconds),
                         "scope":"Extrapolation from representative training rows; excludes checkpoint saves, setup and teacher-cache export."},
            "environment":{"torch":torch.__version__,"cuda":torch.version.cuda,
                           "gpus":[torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())]},
            "trained_checkpoint_exported":False,"probe_weights_discarded":True}


def main():
    import os
    torch.set_num_threads(max(1,min(4,os.cpu_count() or 1)))
    parser = argparse.ArgumentParser()
    parser.add_argument("--config",required=True)
    parser.add_argument("--report",required=True)
    args = parser.parse_args()
    config = read_json(args.config)
    try:
        result = run_probe(config)
    except Exception as exc:
        from common import safe_error
        result = {"status":"failed","architecture":config["architecture"],
                  "request_fingerprint":config["request_fingerprint"],
                  "error_type":type(exc).__name__,"error":safe_error(exc)}
        write_json(args.report,result)
        raise
    write_json(args.report,result)
    print("Probe result:",result["status"],flush=True)


if __name__=="__main__":
    main()

