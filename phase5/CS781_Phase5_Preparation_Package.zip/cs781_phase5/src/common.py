"""File identities, original legal BPE and document chunk geometry."""

import hashlib, json, os, pickle, re, shutil, time, zipfile

from pathlib import Path

import numpy as np

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(8 * 2**20), b""):
            h.update(block)
    return h.hexdigest()

def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False), encoding="utf-8")
    temporary.replace(path)

def read_json(path):
    def pairs(items):
        result = {}
        for k, v in items:
            if k in result:
                raise ValueError("Duplicate JSON key: " + str(k))
            result[k] = v
        return result
    def invalid(x):
        raise ValueError("Nonfinite JSON value: " + x)
    return json.loads(Path(path).read_text(encoding="utf-8-sig"),
                      object_pairs_hook=pairs, parse_constant=invalid)

def safe_error(exc):
    return re.sub(r"hf_[A-Za-z0-9]+", "[redacted]", str(exc))[:3000]

def discover(filename, input_root, supplied=None, hint=None, extraction_root=None):
    """Find one unambiguous file; extract only requested members and companions."""
    base = Path(supplied) if supplied else Path(input_root)
    hints = [hint] if isinstance(hint, str) else list(hint or [])
    if supplied and not base.exists():
        raise FileNotFoundError("Input path does not exist: " + str(base))
    candidates = [base] if base.is_file() and base.name == filename else (
        list(base.rglob(filename)) if base.is_dir() else [])
    if hints and not supplied:
        candidates = [p for p in candidates if any(h.lower() in str(p).lower() for h in hints)]
    candidates = sorted(set(p.resolve() for p in candidates))
    if len(candidates) == 1:
        return candidates[0]
    if len(candidates) > 1:
        raise ValueError("Several " + filename + " files found. Set its exact input path: " +
                         " | ".join(str(p) for p in candidates[:10]))
    archives = [base] if base.is_file() and base.suffix.lower() == ".zip" else (
        sorted(base.rglob("*.zip")) if base.is_dir() else [])
    matches = []
    for archive in archives:
        try:
            with zipfile.ZipFile(archive) as z:
                for info in z.infolist():
                    if not info.is_dir() and Path(info.filename).name == filename:
                        if not hints or supplied or any(h.lower() in (str(archive)+"/"+info.filename).lower() for h in hints):
                            matches.append((archive, info.filename))
        except zipfile.BadZipFile:
            continue
    if len(matches) != 1:
        raise FileNotFoundError("Need exactly one " + filename + " for " + str(hint or supplied) +
                                "; archive matches=" + str(len(matches)) +
                                ". Attach the original dataset or set its exact path.")
    archive, member = matches[0]
    target_root = Path(extraction_root) / hashlib.sha256(str(archive.resolve()).encode()).hexdigest()[:12]
    parent = Path(member).parent
    with zipfile.ZipFile(archive) as z:
        wanted = [member]
        for companion in ("cache_manifest.json", "sources/phase1_decoder.py", "sources/architecture_models.py"):
            name = str(parent / companion)
            if name in z.namelist():
                wanted.append(name)
        for name in wanted:
            target = (target_root / name).resolve()
            if not target.is_relative_to(target_root.resolve()):
                raise ValueError("Unsafe archive member.")
            info = z.getinfo(name)
            if shutil.disk_usage(target_root.parent if target_root.parent.exists() else Path.cwd()).free < info.file_size + 2**28:
                raise RuntimeError("Insufficient disk for the selected checkpoint.")
            target.parent.mkdir(parents=True, exist_ok=True)
            with z.open(name) as src, open(str(target) + ".tmp", "wb") as dst:
                shutil.copyfileobj(src, dst, 8 * 2**20)
            Path(str(target) + ".tmp").replace(target)
    return target_root / member

def load_tokenizer(path, expected_hash=None):
    from a1_tokenizer import A1BPETokenizer
    path = Path(path)
    manifest = read_json(path.parent / "cache_manifest.json")
    digest = sha256(path)
    if digest != manifest["tokenizer_state_sha256"] or (expected_hash and digest != expected_hash):
        raise ValueError("Use the original prep-2 tokenizer and its matching cache_manifest.json.")
    with open(path, "rb") as f:
        saved = pickle.load(f)  # Only the user's own Phase 1 preparation is loaded.
    if saved["signature"] != manifest["tokenizer_signature"]:
        raise ValueError("Tokenizer signature mismatch.")
    tokenizer = A1BPETokenizer()
    tokenizer.__dict__.update(saved["state"])
    if tokenizer.vocab[:4] != [b"<pad>", b"<unk>", b"<s>", b"</s>"]:
        raise ValueError("Unexpected reserved token IDs.")
    probes = ["A court allowed the appeal.", "Dismissed.\nThe judgment follows.", "धारा १२"]
    for sample in probes:
        ids = tokenizer.encode(sample)
        if tokenizer.decode(ids) != sample or not ids or min(ids) < 4 or max(ids) >= len(tokenizer.vocab):
            raise ValueError("Saved BPE round-trip or token-ID range check failed.")
    return tokenizer, saved["signature"], manifest

def chunk_spans(n_tokens, total_tokens=512, overlap=64):
    content = total_tokens - 2
    if n_tokens < 1 or content < 1 or not 0 <= overlap < content:
        raise ValueError("Invalid chunk geometry.")
    spans = []
    start = 0
    while True:
        stop = min(start + content, n_tokens)
        spans.append((start, stop))
        if stop == n_tokens:
            return spans
        start += content - overlap

def selected_spans(n_tokens, total_tokens, overlap, max_chunks, policy="uniform"):
    spans = chunk_spans(n_tokens, total_tokens, overlap)
    if max_chunks < 1:
        raise ValueError("max_chunks must be positive.")
    if len(spans) <= max_chunks:
        return spans
    if policy == "uniform":
        indices = np.linspace(0, len(spans) - 1, max_chunks).round().astype(int).tolist()
    elif policy == "head":
        indices = list(range(max_chunks))
    elif policy == "tail":
        indices = list(range(len(spans) - max_chunks, len(spans)))
    elif policy == "head_tail":
        left = (max_chunks + 1) // 2
        indices = list(range(left)) + list(range(len(spans) - (max_chunks - left), len(spans)))
    else:
        raise ValueError("Unknown chunk selection policy.")
    if len(set(indices)) != max_chunks:
        raise AssertionError("Repeated selected chunk.")
    return [spans[i] for i in sorted(indices)]

def coverage(n_tokens, spans):
    covered, end = 0, 0
    for start, stop in spans:
        covered += max(0, stop - max(start, end))
        end = max(end, stop)
    return covered / n_tokens
