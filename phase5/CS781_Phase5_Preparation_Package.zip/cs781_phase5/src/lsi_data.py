"""Official LSI data, label audits and resumable packed legal-BPE tokens."""
import collections
import functools
import gc
import hashlib
import json
import math
import os
import re
import shutil
import time
import zipfile
from pathlib import Path
import numpy as np
import pandas as pd
from common import read_json, write_json, sha256, safe_error, selected_spans, coverage


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def _copy(source, target):
    target = Path(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(target.name + ".tmp")
    if Path(source).resolve() != target.resolve():
        shutil.copyfile(source, temporary)
        temporary.replace(target)


def official_data(root, input_root="/kaggle/input", local_input=None, revision=None):
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    files = {"train": "Train/train.json", "dev": "Train/dev.json", "test": "Test/test.json"}
    manifest_path = root / "download_manifest.json"
    if manifest_path.exists():
        saved = read_json(manifest_path)
        if revision not in (None, "main", saved["revision"]):
            raise ValueError("The data revision changed. Use a new preparation directory.")
        if not all((root / n).is_file() and sha256(root / n) == h for n, h in saved["sha256"].items()):
            raise ValueError("Working JSON files differ from their saved hashes.")
        print("Reusing verified LSI files:", saved["revision"], flush=True)
        return root, saved
    if local_input is None and Path(input_root).exists():
        candidates = [p.parent.parent for p in Path(input_root).rglob("train.json")
                      if p.parent.name.lower() == "train"
                      and "phase5lsi" in re.sub("[^a-z0-9]", "", str(p).lower())
                      and (p.parent / "dev.json").is_file()
                      and (p.parent.parent / "Test/test.json").is_file()]
        candidates = sorted(set(candidates))
        if len(candidates) == 1:
            local_input = str(candidates[0])
        elif len(candidates) > 1:
            raise ValueError("Multiple Phase 5 data folders found. Set LOCAL_LSI_INPUT.")
    resolved = {}
    if local_input is not None:
        source = Path(local_input)
        if source.is_file() and source.suffix.lower() == ".zip":
            with zipfile.ZipFile(source) as archive:
                for split, suffix in files.items():
                    matches = [n for n in archive.namelist()
                               if n.lower().endswith(suffix.lower())]
                    if len(matches) != 1:
                        raise ValueError("Choose an LSI-only ZIP containing one " + suffix)
                    target = root / suffix
                    target.parent.mkdir(parents=True, exist_ok=True)
                    with archive.open(matches[0]) as src, target.with_suffix(".json.tmp").open("wb") as dst:
                        shutil.copyfileobj(src, dst, 8 * 1024**2)
                    target.with_suffix(".json.tmp").replace(target)
                    resolved[split] = matches[0]
        elif source.is_dir():
            for split, suffix in files.items():
                matches = [p for p in source.rglob(Path(suffix).name)
                           if str(p).lower().endswith(suffix.lower())]
                if len(matches) != 1:
                    raise ValueError("Set LOCAL_LSI_INPUT to the folder containing one " + suffix)
                _copy(matches[0], root / suffix)
                resolved[split] = str(matches[0])
        else:
            raise FileNotFoundError(source)
        manifest = {"repo_id": "Exploration-Lab/CS-781-Capstone", "revision": "local_copy",
                    "provenance": "attached data; byte identities recorded; remote revision unverified",
                    "resolved_files": resolved}
    else:
        from huggingface_hub import HfApi, hf_hub_download
        token = os.environ.get("HF_TOKEN")
        if not token:
            try:
                from kaggle_secrets import UserSecretsClient
                token = UserSecretsClient().get_secret("HF_TOKEN")
            except Exception:
                token = None
        repo = "Exploration-Lab/CS-781-Capstone"
        try:
            api = HfApi(token=token)
            commit = api.dataset_info(repo, revision=revision or "main").sha
            names = api.list_repo_files(repo, repo_type="dataset", revision=commit)
            for split, suffix in files.items():
                wanted = "Phase_5_LSI/" + suffix
                matches = [n for n in names if n.lower() == wanted.lower()
                           or n.lower().endswith("/" + wanted.lower())]
                if len(matches) != 1:
                    write_json(root / "repository_paths.json", [n for n in names if "lsi" in n.lower()])
                    raise ValueError("Could not resolve " + wanted + "; repository paths were saved.")
                resolved[split] = matches[0]
                path = hf_hub_download(repo, filename=matches[0], repo_type="dataset",
                                       revision=commit, token=token)
                _copy(path, root / suffix)
            manifest = {"repo_id": repo, "revision": commit,
                        "provenance": "official commit-pinned download", "resolved_files": resolved}
        except Exception as exc:
            raise RuntimeError("LSI download failed. Enable Internet and HF_TOKEN access, or set "
                               "LOCAL_LSI_INPUT. Details: " + safe_error(exc)) from None
        finally:
            token = None
    manifest["sha256"] = {name: sha256(root / name) for name in files.values()}
    write_json(manifest_path, manifest)
    return root, manifest


def normalize_records(raw, split, label_field="labels"):
    if isinstance(raw, dict):
        wrappers = [k for k in ("data", "records", "examples", "cases")
                    if isinstance(raw.get(k), list) and "text" not in raw]
        if len(wrappers) == 1:
            raw = raw[wrappers[0]]
    if isinstance(raw, list):
        items = [(None, row) for row in raw]
    elif isinstance(raw, dict) and "id" in raw and "text" in raw:
        items = [(None, raw)]
    elif isinstance(raw, dict):
        items = list(raw.items())
    else:
        raise ValueError(split + ": expected records or an ID-to-record dictionary.")
    rows, schema = [], collections.Counter()
    for i, (key, record) in enumerate(items):
        if split == "test" and key is not None and isinstance(record, (str, list)):
            record = {"id": key, "text": record}
        if not isinstance(record, dict):
            raise ValueError(split + ": invalid case record.")
        case_id = record.get("id", key)
        if not isinstance(case_id, str) or not case_id.strip() or (key is not None and case_id != key):
            raise ValueError(split + ": preserve a valid original string ID.")
        text = record.get("text")
        if isinstance(text, list) and all(isinstance(s, str) for s in text):
            text = "\n".join(text)
            schema["sentence_lists_joined_with_newlines"] += 1
        if not isinstance(text, str) or not text.strip():
            raise ValueError(split + "/" + case_id + ": empty or invalid text.")
        labels = None
        if split != "test":
            labels = record.get(label_field)
            if not isinstance(labels, list) or any(type(c) is not int or c < 0 for c in labels):
                raise ValueError(split + "/" + case_id + ": labels must be a list of nonnegative integer IDs.")
            schema["duplicate_label_entries_removed"] += len(labels) - len(set(labels))
            labels = sorted(set(labels))
        rows.append({"id": case_id, "row_uid": f"{split}:{i:08d}:{case_id}",
                     "row_index": i, "split": split, "text": text, "labels": labels,
                     "text_sha256": hashlib.sha256(text.encode()).hexdigest()})
    if not rows:
        raise ValueError(split + ": no rows found.")
    if split == "test" and len({r["id"] for r in rows}) != len(rows):
        raise ValueError("Official test IDs must be unique; no silent overwrite is permitted.")
    schema["rows"] = len(rows)
    return rows, dict(schema)


def load_documents(root, label_field="labels"):
    rows, schemas = [], {}
    for split, name in (("train", "Train/train.json"), ("dev", "Train/dev.json"), ("test", "Test/test.json")):
        part, schema = normalize_records(read_json(Path(root) / name), split, label_field)
        rows.extend(part)
        schemas[split] = schema
    return rows, schemas


def label_vocabulary(rows, supplied=None):
    observed = sorted({c for r in rows if r["labels"] is not None for c in r["labels"]})
    if supplied is None:
        ids, source = observed, "train_dev_observed_union"
    else:
        value = read_json(supplied)
        if isinstance(value, dict) and isinstance(value.get("label_ids"), list):
            value = value["label_ids"]
        elif isinstance(value, dict) and all(str(k).isdigit() for k in value):
            value = [int(k) for k in value]
        if not isinstance(value, list) or any(type(c) is not int or c < 0 for c in value):
            raise ValueError("LABEL_VOCAB_INPUT must contain integer IDs, label_ids, or ID-to-name entries.")
        if len(value) != len(set(value)):
            raise ValueError("Duplicate IDs in the supplied label vocabulary.")
        ids, source = sorted(value), "supplied_label_vocabulary"
        if not set(observed).issubset(ids):
            raise ValueError("Observed labels are missing from the supplied vocabulary.")
    if not ids:
        raise ValueError("No positive statute IDs were found.")
    return {"label_ids": ids, "id_to_column": {str(c): j for j, c in enumerate(ids)},
            "columns": len(ids), "source": source,
            "official_evaluator_verified": False,
            "note": "Internal columns are contiguous; original statute IDs are preserved at export."}


def training_selection(rows, deduplicate=True):
    seen, selected = set(), []
    for row in rows:
        if row["split"] != "train":
            continue
        key = (row["id"], row["text_sha256"], tuple(row["labels"]))
        if not deduplicate or key not in seen:
            selected.append(row)
            seen.add(key)
    return selected


def targets(rows, label_ids):
    columns = {c: j for j, c in enumerate(label_ids)}
    y = np.zeros((len(rows), len(label_ids)), dtype=np.float32)
    for i, row in enumerate(rows):
        if row["labels"] is None:
            raise ValueError("Loss targets require labelled rows.")
        for c in row["labels"]:
            y[i, columns[c]] = 1
    return y


def metrics(y, pred):
    y, pred = np.asarray(y, dtype=bool), np.asarray(pred, dtype=bool)
    if y.ndim != 2 or y.shape != pred.shape or not len(y):
        raise ValueError("Expected nonempty multi-label matrices with matching shapes.")
    tp, fp, fn = (np.sum(y & pred, axis=0), np.sum(~y & pred, axis=0), np.sum(y & ~pred, axis=0))
    divide = lambda a,b: np.divide(a,b,out=np.zeros_like(a,dtype=float),where=b!=0)
    f1 = divide(2*tp,2*tp+fp+fn)
    denominator = int(2*tp.sum()+fp.sum()+fn.sum())
    return {"macro_f1": float(f1.mean()),
            "micro_f1": float(2*tp.sum()/denominator) if denominator else 0.,
            "macro_precision": float(divide(tp,tp+fp).mean()),
            "macro_recall": float(divide(tp,tp+fn).mean()),
            "subset_accuracy": float(np.all(y==pred,axis=1).mean()),
            "mean_predicted_labels": float(pred.sum(1).mean()),
            "label_universe": "all columns in the saved preparation vocabulary"}


def audit_data(rows, schemas, vocabulary, output, deduplicate=True, positive_weight_cap=10.0):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    ids = vocabulary["label_ids"]
    train = training_selection(rows, deduplicate)
    dev = [r for r in rows if r["split"] == "dev"]
    n = len(train)
    counts = collections.Counter(c for r in train for c in r["labels"])
    dev_counts = collections.Counter(c for r in dev for c in r["labels"])
    pos = np.array([counts[c] for c in ids], dtype=np.float64)
    weights = np.clip(np.sqrt((n - pos + .5) / (pos + .5)), 1., positive_weight_cap)
    weights[pos == 0] = 1.
    bias = np.log(weights * (pos + .5) / (n - pos + .5))
    stats = []
    for j, c in enumerate(ids):
        stats.append({"statute_id": c, "train_positive": int(pos[j]), "dev_positive": dev_counts[c],
                      "positive_weight": float(weights[j]), "initial_logit_bias": float(bias[j]),
                      "frequency_group": "unseen" if pos[j] == 0 else
                                         "rare" if pos[j] < 20 else "medium" if pos[j] < 100 else "frequent"})
    pd.DataFrame(stats).to_csv(output / "label_frequencies.csv", index=False)
    summary = {"schemas": schemas, "label_vocabulary": vocabulary,
               "effective_train_rows": n, "training_duplicates_removed": sum(r["split"] == "train" for r in rows)-n,
               "train_selection_fingerprint": digest([r["row_uid"] for r in train]),
               "labels_without_train_positives": [c for c in ids if counts[c] == 0],
               "labels_without_dev_positives": [c for c in ids if dev_counts[c] == 0],
               "cross_split_overlap": [], "split_statistics": {}}
    for split in ("train", "dev", "test"):
        part = [r for r in rows if r["split"] == split]
        cardinality = [len(r["labels"]) for r in part if r["labels"] is not None]
        by_input = collections.defaultdict(set)
        for r in part:
            by_input[(r["id"], r["text_sha256"])].add(tuple(r["labels"] or []))
        summary["split_statistics"][split] = {
            "rows": len(part), "unique_original_ids": len({r["id"] for r in part}),
            "unique_forward_inputs": len(by_input),
            "same_input_conflicting_label_sets": sum(len(v) > 1 for v in by_input.values()),
            "mean_characters": float(np.mean([len(r["text"]) for r in part])),
            "labels_per_case": {str(q): float(np.percentile(cardinality, q)) for q in (0, 50, 90, 100)}
                              if cardinality else None}
    for a, b in (("train", "dev"), ("train", "test"), ("dev", "test")):
        left, right = [[r for r in rows if r["split"] == split] for split in (a, b)]
        exact_left = {r["text_sha256"] for r in left}
        norm = lambda r: hashlib.sha256(re.sub(r"\s+", " ", r["text"]).strip().casefold().encode()).hexdigest()
        norm_left = {norm(r) for r in left}
        exact_matches = [r["row_uid"] for r in right if r["text_sha256"] in exact_left]
        norm_matches = [r["row_uid"] for r in right if norm(r) in norm_left]
        summary["cross_split_overlap"].append({
            "a": a, "b": b, "shared_original_ids": len({r["id"] for r in left} & {r["id"] for r in right}),
            "right_rows_matching_exact_text": len(exact_matches),
            "right_rows_matching_normalized_text": len(norm_matches),
            "example_right_row_uids": norm_matches[:30]})
    write_json(output / "data_audit.json", summary)
    write_json(output / "label_vocabulary.json", vocabulary)
    write_json(output / "training_selection.json", {"row_uids": [r["row_uid"] for r in train],
                                                  "fingerprint": summary["train_selection_fingerprint"]})
    y = targets(dev, ids)
    base = np.zeros_like(y)
    frequent = ids.index(max(ids, key=lambda c: counts[c]))
    baselines = [{"baseline": "empty_set", **metrics(y, base)}]
    one = base.copy()
    one[:, frequent] = 1
    baselines.append({"baseline": "most_frequent_training_label", **metrics(y, one)})
    pd.DataFrame(baselines).to_csv(output / "reference_baselines.csv", index=False)
    write_json(output / "loss_settings.json", {"positive_weights": weights.tolist(),
        "initial_logit_bias": bias.tolist(), "training_positive_counts": pos.astype(int).tolist(),
        "effective_train_cases": n, "positive_weight_rule": "sqrt smoothed negative/positive ratio, clipped",
        "positive_weight_cap": positive_weight_cap})
    return train, summary


def build_token_cache(rows, tokenizer, identity, folder, commit_every=64):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    fingerprint = digest(identity)
    manifest_path = folder / "manifest.json"
    if manifest_path.exists():
        manifest = read_json(manifest_path)
        if manifest["fingerprint"] != fingerprint:
            raise ValueError("A different dataset/tokenizer occupies this cache. Use a fresh preparation directory.")
        for name, value in manifest["sha256"].items():
            if sha256(folder / name) != value:
                raise ValueError("Packed token cache checksum failed: " + name)
        print("Reusing packed LSI token cache:", manifest["rows"], "rows", flush=True)
        return manifest
    binary, journal = folder / "token_ids.bin", folder / "rows.jsonl"
    progress = folder / "progress.json"
    state = read_json(progress) if progress.exists() else {
        "fingerprint": fingerprint, "completed_rows": 0, "token_bytes": 0, "journal_bytes": 0}
    if state["fingerprint"] != fingerprint:
        raise ValueError("Interrupted tokenization belongs to a different input identity.")
    completed, token_end, journal_end = [int(state[k]) for k in ("completed_rows", "token_bytes", "journal_bytes")]
    for path, end in ((binary, token_end), (journal, journal_end)):
        path.touch(exist_ok=True)
        if path.stat().st_size < end:
            raise ValueError("A committed token-cache file was truncated.")
        with path.open("r+b") as stream:
            stream.truncate(end)
    if completed:
        prefix = [json.loads(line) for line in journal.read_text().splitlines()]
        if [r["row_uid"] for r in prefix] != [r["row_uid"] for r in rows[:completed]]:
            raise ValueError("Resumed row journal differs from the current dataset.")
    @functools.lru_cache(maxsize=200000)
    def encode_piece(piece):
        return tuple(tokenizer.encode(piece))
    start, last = time.monotonic(), time.monotonic()
    print(f"Tokenizing/reusing {completed:,}/{len(rows):,} rows", flush=True)
    with binary.open("ab") as tokens, journal.open("ab") as metadata:
        def commit():
            tokens.flush()
            metadata.flush()
            os.fsync(tokens.fileno())
            os.fsync(metadata.fileno())
            write_json(progress, {"fingerprint": fingerprint, "completed_rows": completed,
                                  "token_bytes": token_end, "journal_bytes": journal_end})
        try:
            for row in rows[completed:]:
                values = np.asarray([v for piece in re.findall(r"\S+|\s+", row["text"])
                                     for v in encode_piece(piece)], dtype="<i4")
                if values.ndim != 1 or not len(values) or values.min() < 4 or values.max() >= len(tokenizer.vocab):
                    raise ValueError("Invalid content tokens for " + row["row_uid"])
                info = {k: v for k, v in row.items() if k != "text"}
                info.update(token_start=token_end // 4, content_tokens=len(values))
                tokens.write(values.tobytes())
                metadata.write((json.dumps(info, ensure_ascii=False) + "\n").encode())
                token_end += values.nbytes
                journal_end = metadata.tell()
                completed += 1
                if completed % commit_every == 0:
                    commit()
                if time.monotonic() - last >= 20 or completed == len(rows):
                    print(f"Packed {completed:,}/{len(rows):,} | {(time.monotonic()-start)/60:.1f} min", flush=True)
                    last = time.monotonic()
        finally:
            commit()
    cases = [json.loads(line) for line in journal.read_text().splitlines()]
    offsets = np.zeros(len(cases) + 1, dtype=np.int64)
    offsets[1:] = np.cumsum([r["content_tokens"] for r in cases])
    np.save(folder / "offsets.npy", offsets, allow_pickle=False)
    write_json(folder / "index.json", {"fingerprint": fingerprint, "identity": identity, "cases": cases})
    names = ["token_ids.bin", "offsets.npy", "index.json"]
    manifest = {"format_version": 1, "status": "complete", "fingerprint": fingerprint,
                "rows": len(cases), "content_tokens": int(offsets[-1]), "dtype": "<i4",
                "sha256": {n: sha256(folder / n) for n in names}}
    write_json(manifest_path, manifest)
    return manifest


def load_cache(folder, verify=False):
    folder = Path(folder)
    manifest, index = read_json(folder / "manifest.json"), read_json(folder / "index.json")
    if index["fingerprint"] != manifest["fingerprint"]:
        raise ValueError("Token index identity mismatch.")
    if verify:
        for name, expected in manifest["sha256"].items():
            if sha256(folder / name) != expected:
                raise ValueError("Token cache checksum mismatch: " + name)
    tokens = np.memmap(folder / "token_ids.bin", dtype="<i4", mode="r")
    offsets = np.load(folder / "offsets.npy", allow_pickle=False)
    cases = index["cases"]
    if offsets.shape != (len(cases)+1,) or offsets[-1] != len(tokens) or not np.array_equal(
            np.diff(offsets), [r["content_tokens"] for r in cases]):
        raise ValueError("Invalid packed token offsets.")
    rows = [dict(row, token_ids=tokens[int(offsets[i]):int(offsets[i+1])])
            for i, row in enumerate(cases)]
    return rows, index["identity"]


def audit_tokens(rows, output, total_tokens=512, overlap=64, max_chunks=4):
    output = Path(output)
    stats, policies = [], []
    for split in ("train", "dev", "test"):
        part = [r for r in rows if r["split"] == split]
        lengths = [len(r["token_ids"]) for r in part]
        stats.append({"split": split, "rows": len(part), **{
            f"tokens_p{q}": float(np.percentile(lengths, q)) for q in (0, 25, 50, 75, 90, 95, 99, 100)}})
        for policy in ("uniform", "head", "tail", "head_tail"):
            spans = [selected_spans(n, total_tokens, overlap, max_chunks, policy) for n in lengths]
            policies.append({"split": split, "policy": policy,
                             "mean_chunks": float(np.mean([len(s) for s in spans])),
                             "mean_content_coverage": float(np.mean([coverage(n, s) for n, s in zip(lengths, spans)])),
                             "total_selected_token_positions": sum(sum(b-a+2 for a,b in s) for s in spans)})
    pd.DataFrame(stats).to_csv(output / "token_lengths.csv", index=False)
    pd.DataFrame(policies).to_csv(output / "chunk_policy_coverage.csv", index=False)
    return pd.DataFrame(stats), pd.DataFrame(policies)


def collate_cases(rows, label_ids, total_tokens=512, overlap=64, max_chunks=4, policy="uniform"):
    import torch
    spans = [selected_spans(len(r["token_ids"]), total_tokens, overlap, max_chunks, policy) for r in rows]
    k = max(map(len, spans))
    width = max(b-a+2 for ss in spans for a,b in ss)
    ids = torch.zeros((len(rows), k, width), dtype=torch.long)
    lengths = torch.zeros((len(rows), k), dtype=torch.long)
    positions = torch.zeros((len(rows), k, 2), dtype=torch.float32)
    for i, (row, selected) in enumerate(zip(rows, spans)):
        for j, (a,b) in enumerate(selected):
            values = torch.tensor([2]+row["token_ids"][a:b].astype(int).tolist()+[3], dtype=torch.long)
            ids[i,j,:len(values)] = values
            lengths[i,j] = len(values)
            positions[i,j] = torch.tensor([a/len(row["token_ids"]), b/len(row["token_ids"])])
    y = None if any(r["labels"] is None for r in rows) else torch.from_numpy(targets(rows, label_ids))
    return {"ids": ids, "lengths": lengths, "positions": positions}, y

