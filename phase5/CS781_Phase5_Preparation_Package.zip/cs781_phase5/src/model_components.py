"""Shared Phase 1 readouts, adapters and hierarchical components.

Preserved from the checked Phase 4 implementation; LSI heads live in lsi_model.py.
"""
import contextlib
import copy
import math
from dataclasses import replace
import torch
from torch import nn
import torch.nn.functional as F
from torch.utils.checkpoint import checkpoint
from phase1_decoder import DecoderLM, LMConfig
import phase1_shared as shared
import phase1_efficient as efficient


def mask_for(lengths, width):
    return torch.arange(width, device=lengths.device)[None, :] < lengths[:, None]


def mean_content(states, lengths):
    positions = torch.arange(states.shape[1], device=states.device)[None, :]
    valid = (positions > 0) & (positions < lengths[:, None] - 1)
    count = valid.sum(1)
    if not bool((count > 0).all()):
        raise ValueError("Each chunk needs at least one content token.")
    return (states.float() * valid[:, :, None]).sum(1) / count[:, None]


def chunk_states(lm, architecture, ids, lengths, use_checkpoint=False):
    """Return token-context states and a full-context query/last-content readout."""
    if ids.ndim != 2 or lengths.shape != (len(ids),):
        raise ValueError("Expected IDs [chunks,tokens] and lengths [chunks].")
    if not bool(((lengths >= 3) & (lengths <= ids.shape[1])).all()):
        raise ValueError("Invalid nonpadding chunk length.")
    reserve = int(architecture in ("prefix", "encoder_decoder"))
    if ids.shape[1] + reserve > lm.cfg.max_seq_len:
        raise ValueError("Chunk plus classification query exceeds the Phase 1 context budget.")
    allowed = mask_for(lengths, ids.shape[1])[:, None, None, :]
    clean = ids.masked_fill(~allowed[:, 0, 0, :], 0)
    call = lambda block, *args: checkpoint(block, *args, use_reentrant=False,
                                            preserve_rng_state=True) if use_checkpoint else block(*args)
    if architecture == "decoder":
        x = lm.tok_emb(clean) * lm.cfg.embedding_scale + lm.pos_emb[:ids.shape[1]][None]
        for block in lm.blocks:
            x = call(block, x)
        states = lm.ln_f(x)
        readout = states[torch.arange(len(ids), device=ids.device), lengths - 2]
    elif architecture == "efficient":
        x = lm.embed(clean)
        for block in lm.blocks:
            x = call(block, x, lengths)
        states = lm.final_norm(x)
        readout = states[torch.arange(len(ids), device=ids.device), lengths - 2]
    elif architecture == "encoder_decoder":
        memory = lm.embed(clean)
        for block in lm.encoder:
            memory = call(block, memory, allowed)
        states = lm.encoder_norm(memory)
        query = torch.full((len(ids), 1), 2, dtype=torch.long, device=ids.device)
        x = lm.embed(query)
        for block in lm.decoder:
            x = call(block, x, states, allowed)
        readout = lm.decoder_norm(x)[:, 0]
    elif architecture == "prefix":
        p = lm.embed(clean, role=0)
        query = torch.full((len(ids), 1), 2, dtype=torch.long, device=ids.device)
        d = lm.embed(query, offset=lengths, role=1)
        for block in lm.blocks:
            p, d = call(block, p, d, allowed)
        states, readout = lm.final_norm(p), lm.final_norm(d)[:, 0]
    else:
        raise ValueError("Unknown architecture.")
    return states, readout


class Bottleneck(nn.Module):
    def __init__(self, width, bottleneck, dropout):
        super().__init__()
        self.down = nn.Linear(width, bottleneck)
        self.up = nn.Linear(bottleneck, width)
        self.dropout = nn.Dropout(dropout)
        nn.init.zeros_(self.up.weight)
        nn.init.zeros_(self.up.bias)

    def forward(self, x):
        return x + self.dropout(self.up(F.gelu(self.down(x))))


class AdaptedOutput(nn.Module):
    """Adapter after a sublayer output, before its outer residual addition."""
    def __init__(self, original, width, bottleneck, dropout):
        super().__init__()
        self.original = original
        self.adapter = Bottleneck(width, bottleneck, dropout)

    def forward(self, *args, **kwargs):
        return self.adapter(self.original(*args, **kwargs))


class LoRMAPlusLinear(nn.Module):
    """Output-side (I + alpha/r BA) W0 x + original bias."""
    def __init__(self, original, rank, alpha, dropout):
        super().__init__()
        if not isinstance(original, nn.Linear) or not 0 < rank <= min(original.weight.shape):
            raise ValueError("Invalid LoRMA+ linear target or rank.")
        self.original = original
        self.lorma_A = nn.Parameter(original.weight.new_empty(rank, original.out_features))
        self.lorma_B = nn.Parameter(original.weight.new_zeros(original.out_features, rank))
        nn.init.kaiming_uniform_(self.lorma_A, a=math.sqrt(5))
        self.dropout = nn.Dropout(dropout)
        self.scaling = alpha / rank
        for p in original.parameters():
            p.requires_grad_(False)

    def forward(self, x):
        base = self.original(x)
        projected = base if self.original.bias is None else base - self.original.bias.to(base.dtype)
        return base + self.scaling * F.linear(F.linear(self.dropout(projected), self.lorma_A), self.lorma_B)


class DocumentBiGRU(nn.Module):
    """Small GRU written with tensor operations, applied only to valid chunks."""
    def __init__(self, width, hidden):
        super().__init__()
        self.hidden = hidden
        self.input = nn.ModuleList([nn.Linear(width, 3 * hidden) for _ in range(2)])
        self.recurrent = nn.ModuleList([nn.Linear(hidden, 3 * hidden) for _ in range(2)])

    def forward(self, x):
        outputs = []
        for direction in range(2):
            hidden = x.new_zeros(self.hidden)
            transformed = self.input[direction](x)
            states = [None] * len(x)
            order = range(len(x)) if direction == 0 else range(len(x)-1, -1, -1)
            for i in order:
                xr, xz, xn = transformed[i].chunk(3, -1)
                hr, hz, hn = self.recurrent[direction](hidden).chunk(3, -1)
                reset, update = torch.sigmoid(xr+hr), torch.sigmoid(xz+hz)
                candidate = torch.tanh(xn + reset*hn)
                hidden = (1-update)*candidate + update*hidden
                states[i] = hidden
            outputs.append(torch.stack(states))
        return torch.cat(outputs, -1)


def compact_efficient(lm, layers):
    if not layers or len(set(layers)) != len(layers) or list(layers) != sorted(layers):
        raise ValueError("Student layers must be distinct, ascending zero-based indices.")
    if min(layers) < 0 or max(layers) >= len(lm.blocks) or len(layers) >= len(lm.blocks):
        raise ValueError("The student must retain fewer than all original efficient blocks.")
    result = efficient.EfficientLM(replace(lm.cfg, n_layers=len(layers)))
    result.tok_emb.load_state_dict(lm.tok_emb.state_dict(), strict=True)
    result.final_norm.load_state_dict(lm.final_norm.state_dict(), strict=True)
    for new, old in enumerate(layers):
        result.blocks[new].load_state_dict(lm.blocks[old].state_dict(), strict=True)
    if result.tok_emb.weight.data_ptr() == lm.tok_emb.weight.data_ptr():
        raise AssertionError("Student and original must not share mutable parameter storage.")
    return result


def configure_dropout(lm, probability):
    lm.cfg = replace(lm.cfg, dropout=float(probability))
    for module in lm.modules():
        if isinstance(module, nn.Dropout):
            module.p = float(probability)
        elif isinstance(module, (shared.Attention, efficient.Attention)):
            module.dropout = float(probability)


def configure_adaptation(lm, architecture, settings):
    configure_dropout(lm, settings["backbone_dropout"])
    for p in lm.parameters():
        p.requires_grad_(False)
    targets = []
    if architecture == "decoder":
        upper = settings["decoder_upper_layers"]
        if not 1 <= upper <= len(lm.blocks):
            raise ValueError("Invalid partial fine-tuning depth.")
        for i in range(len(lm.blocks)-upper, len(lm.blocks)):
            for p in lm.blocks[i].parameters():
                p.requires_grad_(True)
            targets.append("blocks." + str(i))
        for p in lm.ln_f.parameters():
            p.requires_grad_(True)
    elif architecture == "encoder_decoder":
        for group, blocks in (("encoder", lm.encoder), ("decoder", lm.decoder)):
            for i, block in enumerate(blocks):
                names = ("attn", "ffn") if group == "encoder" else ("self_attn", "cross_attn", "ffn")
                for name in names:
                    setattr(block, name, AdaptedOutput(getattr(block, name), lm.cfg.d_model,
                        settings["adapter_bottleneck"], settings["adapter_dropout"]))
                    targets.append(group + "." + str(i) + "." + name)
        if settings["adapter_train_layer_norm"]:
            for module in lm.modules():
                if isinstance(module, nn.LayerNorm):
                    for p in module.parameters():
                        p.requires_grad_(True)
    elif architecture == "prefix":
        for i, block in enumerate(lm.blocks):
            for name in ("q_proj", "k_proj", "v_proj", "out_proj"):
                setattr(block.attn, name, LoRMAPlusLinear(getattr(block.attn, name),
                    settings["lorma_rank"], settings["lorma_alpha"], settings["lorma_dropout"]))
                targets.append("blocks." + str(i) + ".attn." + name)
            for j in (0, 2):
                block.ffn.net[j] = LoRMAPlusLinear(block.ffn.net[j], settings["lorma_rank"],
                    settings["lorma_alpha"], settings["lorma_dropout"])
                targets.append("blocks." + str(i) + ".ffn.net." + str(j))
    elif architecture == "efficient":
        for p in lm.parameters():
            p.requires_grad_(True)
    else:
        raise ValueError("Unknown classifier architecture.")
    return targets




def expected_trainability(model, name):
    if not name.startswith("lm."):
        return True
    if model.architecture == "efficient":
        return True
    if model.architecture == "decoder":
        upper = len(model.lm.blocks)-model.settings["decoder_upper_layers"]
        return name.startswith("lm.ln_f.") or any(name.startswith("lm.blocks."+str(i)+".")
                                                  for i in range(upper, len(model.lm.blocks)))
    if model.architecture == "prefix":
        return name.endswith((".lorma_A", ".lorma_B"))
    if model.architecture == "encoder_decoder":
        if ".adapter." in name:
            return True
        if model.settings["adapter_train_layer_norm"]:
            return any(name.startswith(prefix) for prefix in (
                "lm.encoder_norm.", "lm.decoder_norm.")) or any(
                ".ln"+str(i)+"." in name for i in (1, 2, 3))
        return False
    raise ValueError("Unknown architecture.")


def trainability_audit(model):
    counts = {"total_parameters": 0, "trainable_parameters": 0, "backbone_trainable": 0, "task_trainable": 0}
    for name, p in model.named_parameters():
        if p.requires_grad != expected_trainability(model, name):
            raise AssertionError("Unexpected trainability: " + name)
        counts["total_parameters"] += p.numel()
        if p.requires_grad:
            counts["trainable_parameters"] += p.numel()
            counts["backbone_trainable" if name.startswith("lm.") else "task_trainable"] += p.numel()
    counts["adaptation_targets"] = model.adaptation_targets
    counts["parameter_bytes_float32"] = counts["total_parameters"]*4
    return counts
