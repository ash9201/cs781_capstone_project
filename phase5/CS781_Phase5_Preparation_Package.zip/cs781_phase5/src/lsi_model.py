"""Phase 1-derived multi-label classifiers with label-wise chunk attention."""
import copy
import gc
import math
import torch
from torch import nn
import torch.nn.functional as F
from model_components import (configure_adaptation, compact_efficient, trainability_audit,
                              chunk_states, mean_content, DocumentBiGRU)
from phase1_decoder import DecoderLM, LMConfig
import phase1_shared as shared
import phase1_efficient as efficient


DEFAULT_MODEL_SETTINGS = {
    "seed": 42, "head_seed": 42, "gradient_checkpointing": True, "chunk_microbatch": 2,
    "backbone_dropout": .10, "head_dropout": .30, "decoder_upper_layers": 2,
    "adapter_bottleneck": 64, "adapter_dropout": .05, "adapter_train_layer_norm": True,
    "lorma_rank": 8, "lorma_alpha": 8, "lorma_dropout": .05, "student_layers": [0, 7, 15],
    "projection_dim": 256, "context_hidden": 128, "attention_hidden": 64}


class StatuteClassifier(nn.Module):
    def __init__(self, lm, architecture, settings, labels, initial_bias=None):
        super().__init__()
        self.lm, self.architecture, self.settings = lm, architecture, dict(settings)
        self.use_amp = True
        self.gradient_checkpointing = bool(settings["gradient_checkpointing"])
        self.chunk_microbatch = int(settings["chunk_microbatch"])
        self.adaptation_targets = configure_adaptation(lm, architecture, settings)
        self.label_ids = list(labels)
        if not labels or len(set(labels)) != len(labels):
            raise ValueError("A unique, ordered statute vocabulary is required.")
        width = 2 * settings["context_hidden"]
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(settings["head_seed"])
            self.projection = nn.Linear(2*lm.cfg.d_model+2, settings["projection_dim"])
            self.context = DocumentBiGRU(settings["projection_dim"], settings["context_hidden"])
            self.attention = nn.Sequential(nn.Linear(width, settings["attention_hidden"]), nn.Tanh())
            self.label_queries = nn.Linear(settings["attention_hidden"], len(labels), bias=False)
            self.output_weight = nn.Parameter(torch.empty(len(labels), width))
            nn.init.xavier_uniform_(self.output_weight)
            self.output_bias = nn.Parameter(torch.zeros(len(labels)))
        self.dropout = nn.Dropout(settings["head_dropout"])
        if initial_bias is not None:
            bias = torch.as_tensor(initial_bias, dtype=torch.float32)
            if bias.shape != self.output_bias.shape or not torch.isfinite(bias).all():
                raise ValueError("Invalid prevalence-based output biases.")
            with torch.no_grad():
                self.output_bias.copy_(bias)

    def chunk_vectors(self, ids, lengths):
        states, readout = chunk_states(self.lm, self.architecture, ids, lengths,
            self.training and self.gradient_checkpointing)
        return torch.cat([mean_content(states, lengths), readout.float()], -1)

    def forward(self, ids, lengths, positions):
        if ids.ndim != 3 or lengths.shape != ids.shape[:2] or positions.shape != (*ids.shape[:2], 2):
            raise ValueError("Expected case/chunk/token inputs and two relative positions per chunk.")
        logits, attention = [], []
        with torch.autocast("cuda", dtype=torch.float16, enabled=ids.is_cuda and self.use_amp):
            for b in range(len(ids)):
                active = lengths[b] > 0
                n = int(active.sum())
                if n == 0 or not bool(active[:n].all()) or bool(active[n:].any()):
                    raise ValueError("Real chunks must form a nonempty prefix.")
                pieces = []
                for start in range(0, n, self.chunk_microbatch):
                    stop = min(start + self.chunk_microbatch, n)
                    width = int(lengths[b, start:stop].max())
                    pieces.append(self.chunk_vectors(ids[b, start:stop, :width], lengths[b, start:stop]))
                encoded = torch.cat(pieces)
                projected = torch.tanh(self.projection(torch.cat([encoded, positions[b,:n].float()], -1)))
                contextual = self.context(self.dropout(projected))
                alpha = torch.softmax(self.label_queries(self.attention(contextual)).float(), dim=0)
                documents = alpha.transpose(0, 1) @ contextual.float()
                z = (self.dropout(documents) * self.output_weight).sum(-1) + self.output_bias
                logits.append(z)
                attention.append(F.pad(alpha, (0, 0, 0, ids.shape[1]-n)))
        return {"logits": torch.stack(logits).float(),
                "chunk_attention": torch.stack(attention),
                "device_ids": ids.new_full((len(ids),), ids.device.index if ids.is_cuda else -1)}


def load_original(path, architecture, signature):
    saved = torch.load(path, map_location="cpu", weights_only=False)
    if saved.get("tokenizer_signature") != signature:
        raise ValueError("Phase 1 checkpoint and original prep-2 tokenizer signatures disagree.")
    cfg = saved["model_config"]
    if cfg.get("vocab_size") != signature.get("vocab_size"):
        raise ValueError("Checkpoint vocabulary size differs from its tokenizer signature.")
    if architecture == "decoder":
        model = DecoderLM(LMConfig(**cfg))
    elif architecture == "efficient":
        model = efficient.EfficientLM(efficient.ModelConfig(**cfg))
    else:
        config = shared.ModelConfig(**cfg)
        if config.architecture != architecture:
            raise ValueError("The checkpoint has a different architecture.")
        model = shared.EncoderDecoderLM(config) if architecture == "encoder_decoder" else shared.PrefixLM(config)
    if not torch.equal(saved["model_state"]["tok_emb.weight"], saved["model_state"]["head.weight"]):
        raise ValueError("Saved embedding and tied LM-head values differ.")
    model.load_state_dict(saved["model_state"], strict=True)
    if model.head.weight is not model.tok_emb.weight:
        raise AssertionError("Native embedding/output tying was lost.")
    report = {"model_config": cfg, "strict_state_dict_load": True,
              "original_parameters": sum(p.numel() for p in model.parameters()),
              "tokenizer_signature_matches": True, "tied_embedding_preserved": True}
    del saved
    gc.collect()
    return model, report


def make_classifier(original, architecture, labels, loss_settings, model_settings=None):
    settings = copy.deepcopy(DEFAULT_MODEL_SETTINGS)
    settings.update(model_settings or {})
    backbone = compact_efficient(original, settings["student_layers"]) if architecture == "efficient" else original
    model = StatuteClassifier(backbone, architecture, settings, labels, loss_settings["initial_logit_bias"])
    return model, trainability_audit(model)


def weighted_bce(logits, target, positive_weights, reduction="mean"):
    if logits.shape != target.shape or target.ndim != 2:
        raise ValueError("Expected logits/targets [cases,statutes].")
    if not bool(((target == 0) | (target == 1)).all()):
        raise ValueError("Gold targets must be multi-hot vectors.")
    return F.binary_cross_entropy_with_logits(logits.float(), target.float(),
        pos_weight=positive_weights, reduction=reduction)


def bernoulli_distillation(student, teacher, temperature=2.0):
    if student.shape != teacher.shape or student.ndim != 2 or temperature <= 0:
        raise ValueError("Teacher/student label shapes or temperature are invalid.")
    t = temperature
    q = torch.sigmoid(teacher.detach().float() / t)
    cross_entropy = F.binary_cross_entropy_with_logits(student.float() / t, q, reduction="none")
    teacher_entropy = F.binary_cross_entropy_with_logits(teacher.detach().float() / t, q, reduction="none")
    return (cross_entropy - teacher_entropy).mean() * t * t

