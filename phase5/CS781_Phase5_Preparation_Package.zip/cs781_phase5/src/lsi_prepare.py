"""Preparation orchestration and exported audit/timing records for Phase 5."""
import hashlib
import json
import math
import os
import queue
import shutil
import subprocess
import sys
import threading
import time
import zipfile
from pathlib import Path
import pandas as pd
from common import discover, load_tokenizer, read_json, write_json, sha256, safe_error
from lsi_data import (official_data, load_documents, label_vocabulary, audit_data, digest,
                      build_token_cache, load_cache, audit_tokens, training_selection, targets, metrics)

SOURCE_DIR = Path(__file__).resolve().parent


def restore_prepared(config):
    root = Path(config["project_root"])
    if (root/"prepared"/"cache"/"manifest.json").exists():
        return False
    supplied = config.get("prepared_input")
    if not supplied and config.get("reuse_attached_preparation",True):
        candidates = [p.parent.parent.parent for p in Path(config["input_root"]).rglob("manifest.json")
                      if p.parent.name=="cache" and p.parent.parent.name=="prepared"
                      and (p.parent/"index.json").exists()
                      and "phase5" in str(p).lower()]
        candidates = sorted(set(candidates))
        if len(candidates)>1:
            raise ValueError("Several prepared Phase 5 caches found. Set PREPARED_INPUT.")
        if candidates:
            supplied = str(candidates[0])
        else:
            archives = list(Path(config["input_root"]).rglob("phase5_lsi_prepared_data.zip"))
            if len(archives)==1:
                supplied = str(archives[0])
    if not supplied:
        return False
    source = Path(supplied)
    print("Staging reusable Phase 5 preparation:",source,flush=True)
    allowed = lambda name: name.startswith(("prepared/cache/","reports/","metadata/"))
    if source.is_file():
        with zipfile.ZipFile(source) as archive:
            for member in archive.infolist():
                if member.is_dir():
                    continue
                parts = Path(member.filename).parts
                relative = Path(*parts[1:]).as_posix()
                if not parts or parts[0]!="phase5_lsi_prepared" or not allowed(relative):
                    raise ValueError("Unexpected prepared-cache archive member.")
                target = (root/relative).resolve()
                if not target.is_relative_to(root.resolve()):
                    raise ValueError("Unsafe prepared-cache path.")
                target.parent.mkdir(parents=True,exist_ok=True)
                with archive.open(member) as src,target.with_suffix(target.suffix+".tmp").open("wb") as dst:
                    shutil.copyfileobj(src,dst,8*1024**2)
                target.with_suffix(target.suffix+".tmp").replace(target)
    elif source.is_dir():
        for p in source.rglob("*"):
            if p.is_file() and allowed(p.relative_to(source).as_posix()):
                target = root/p.relative_to(source)
                target.parent.mkdir(parents=True,exist_ok=True)
                shutil.copyfile(p,target)
    else:
        raise FileNotFoundError(source)
    load_cache(root/"prepared"/"cache",verify=True)
    return True


def resolve_tokenizer(config):
    reference = read_json(SOURCE_DIR/"phase1_reference.json")["tokenizer"]
    path = discover("tokenizer_state.pkl",config["input_root"],config.get("tokenizer_input"),
                    ["prep_002_mixed16k","prep-2"],Path(config["project_root"])/"extracted_inputs")
    tokenizer,signature,_ = load_tokenizer(path,reference["sha256"])
    if signature != reference["signature"]:
        raise ValueError("Original tokenizer signature differs from the saved Phase 1 reference.")
    record = {"path":str(path),"sha256":sha256(path),"signature":signature,
              "vocab_size":len(tokenizer.vocab),"retrained":False,"round_trip_checks":"passed"}
    write_json(Path(config["project_root"])/"reports"/"tokenizer.json",record)
    return tokenizer,record


def prepare_data(config):
    root = Path(config["project_root"])
    (root/"reports").mkdir(parents=True,exist_ok=True)
    (root/"metadata").mkdir(exist_ok=True)
    write_json(root/"metadata"/"preparation_settings.json",config)
    protocol = {k:config[k] for k in ("deduplicate_training","positive_weight_cap","label_field")}
    if (root/"prepared"/"cache"/"manifest.json").exists():
        saved_protocol = read_json(root/"metadata"/"prepared_protocol.json")
        if protocol != saved_protocol:
            raise ValueError("The prepared training/weighting protocol changed. Use a fresh preparation directory.")
        cached,identity = load_cache(root/"prepared"/"cache",verify=True)
        if config.get("hf_revision") not in (None,"main",identity["data"]["revision"]):
            raise ValueError("Requested dataset revision differs from the prepared cache.")
        if config.get("label_vocab_input"):
            current = label_vocabulary(cached,config["label_vocab_input"])
            if current["label_ids"] != read_json(root/"reports"/"label_vocabulary.json")["label_ids"]:
                raise ValueError("The supplied label vocabulary differs from the prepared columns.")
        print("Reusing verified packed LSI preparation; raw JSON download/tokenization skipped.",flush=True)
        return None,identity["data"],read_json(root/"reports"/"data_audit.json")
    data_root,manifest = official_data(root/"official_data"/"Phase_5_LSI",config["input_root"],
                                      config.get("local_lsi_input"),config.get("hf_revision"))
    rows,schemas = load_documents(data_root,config["label_field"])
    vocabulary = label_vocabulary(rows,config.get("label_vocab_input"))
    train,audit = audit_data(rows,schemas,vocabulary,root/"reports",
                            config["deduplicate_training"],config["positive_weight_cap"])
    write_json(root/"metadata"/"data_manifest.json",manifest)
    write_json(root/"metadata"/"prepared_protocol.json",protocol)
    print("LSI rows:",{s:sum(r["split"]==s for r in rows) for s in ("train","dev","test")},flush=True)
    print("Effective training rows:",len(train),"| statute columns:",vocabulary["columns"],flush=True)
    print("Label schema source:",vocabulary["source"],flush=True)
    return rows,manifest,audit


def prepare_tokens(config,rows,data_manifest):
    root = Path(config["project_root"])
    tokenizer,record = resolve_tokenizer(config)
    identity = {"data":data_manifest,"tokenizer_sha256":record["sha256"],
                "tokenizer_signature":record["signature"],"record_identity_version":1}
    if rows is not None:
        build_token_cache(rows,tokenizer,identity,root/"prepared"/"cache")
    else:
        saved = read_json(root/"prepared"/"cache"/"index.json")["identity"]
        if saved != identity:
            raise ValueError("Restored preparation and original tokenizer identities differ.")
    manifest = read_json(root/"prepared"/"cache"/"manifest.json")
    cached,_ = load_cache(root/"prepared"/"cache")
    tables = audit_tokens(cached,root/"reports",config["total_tokens"],config["overlap"],config["max_chunks"])
    write_json(root/"metadata"/"cache_identity.json",manifest)
    return tables


def _stage_checkpoint(source,target,expected):
    target = Path(target)
    if target.exists():
        if sha256(target) != expected:
            raise ValueError("Staged checkpoint differs from the original reference: "+str(target))
        return target
    target.parent.mkdir(parents=True,exist_ok=True)
    size = Path(source).stat().st_size
    if shutil.disk_usage(target.parent).free < size+512*1024**2:
        raise RuntimeError("Insufficient working storage. Set STAGE_CHECKPOINTS=False or free space.")
    tmp = target.with_suffix(".pt.tmp")
    checksum = hashlib.sha256()
    copied,last = 0,time.monotonic()
    with open(source,"rb") as src,tmp.open("wb") as dst:
        while block:=src.read(8*1024**2):
            checksum.update(block)
            dst.write(block)
            copied += len(block)
            if time.monotonic()-last > 15:
                print(f"Staging {target.parent.name}: {copied/2**20:.0f}/{size/2**20:.0f} MiB",flush=True)
                last = time.monotonic()
    if checksum.hexdigest() != expected:
        tmp.unlink(missing_ok=True)
        raise ValueError("Select the matching original Phase 1 checkpoint: "+str(source))
    tmp.replace(target)
    return target


def resolve_checkpoints(config):
    root = Path(config["project_root"])
    reference = read_json(SOURCE_DIR/"phase1_reference.json")["phase1_inputs"]
    records = {}
    for architecture in config["architectures"]:
        spec = reference[architecture]
        print("Finding original checkpoint:",architecture,flush=True)
        hint = Path(spec["path"]).parent.name
        supplied = config["checkpoint_inputs"].get(architecture)
        if supplied and Path(supplied).is_file() and Path(supplied).suffix.lower()!=".zip":
            source = Path(supplied)
        else:
            source = discover("best_model.pt",config["input_root"],supplied,[hint],root/"extracted_inputs")
        if config["stage_checkpoints"]:
            path = _stage_checkpoint(source,root/"staged_checkpoints"/architecture/"best_model.pt",spec["sha256"])
        else:
            if sha256(source) != spec["sha256"]:
                raise ValueError("Phase 1 checkpoint hash mismatch: "+architecture)
            path = source
        records[architecture] = {"original_path":str(source),"path":str(path),
                                 "sha256":spec["sha256"],"bytes":path.stat().st_size,
                                 "byte_identity":"passed",
                                 "tensor_load_check":"performed separately by the model probe"}
        write_json(root/"metadata"/"phase1_inputs.json",records)
    return pd.DataFrame([{"architecture":k,**v} for k,v in records.items()])


def validate_predictions(records,expected_ids,label_ids):
    if not isinstance(records,list) or len(records)!=len(expected_ids):
        raise ValueError("Missing or extra prediction records.")
    seen,valid = set(),set(label_ids)
    for row in records:
        if not isinstance(row,dict) or set(row)!={"id","pred"}:
            raise ValueError("Expected exactly id and pred fields.")
        if not isinstance(row["id"],str) or row["id"] in seen:
            raise ValueError("Invalid or duplicated prediction ID.")
        if not isinstance(row["pred"],list) or any(type(c) is not int or c not in valid for c in row["pred"]):
            raise ValueError("Predictions require valid integer statute IDs.")
        if len(row["pred"])!=len(set(row["pred"])):
            raise ValueError("Duplicated statute in a prediction.")
        seen.add(row["id"])
    if seen!=set(expected_ids):
        raise ValueError("Prediction ID set differs from the expected test IDs.")
    return True


def evaluator_check(config):
    root = Path(config["project_root"])
    rows,_ = load_cache(root/"prepared"/"cache")
    dev = [r for r in rows if r["split"]=="dev"]
    labels = read_json(root/"reports"/"label_vocabulary.json")["label_ids"]
    frequent = pd.read_csv(root/"reports"/"label_frequencies.csv").sort_values("train_positive").iloc[-1]["statute_id"]
    prediction = [{"id":r["row_uid"],"pred":[int(frequent)]} for r in dev]
    truth = [{"id":r["row_uid"],"gold":r["labels"]} for r in dev]
    validate_predictions(prediction,[r["row_uid"] for r in dev],labels)
    folder = root/"evaluator_check"
    folder.mkdir(exist_ok=True)
    write_json(folder/"truth.json",truth)
    write_json(folder/"prediction.json",prediction)
    y = targets(dev,labels)
    yp = targets([dict(r,labels=[int(frequent)]) for r in dev],labels)
    result = {"internal_schema_check":"passed","internal_metrics":metrics(y,yp),
              "official_status":"not_attached","official_evaluator_path":None,
              "scope":"One full-dev most-frequent-label smoke case; all saved vocabulary columns are scored internally."}
    path = config.get("evaluator_input")
    if path is None and Path(config["input_root"]).exists():
        candidates = list(Path(config["input_root"]).rglob("evaluate_phase5.py"))
        if len(candidates)==1:
            path = str(candidates[0])
    if path:
        path = Path(path)
        _copy_target = root/"metadata"/"evaluate_phase5.py"
        shutil.copyfile(path,_copy_target)
        try:
            run = subprocess.run([sys.executable,str(path),"--truth",str(folder/"truth.json"),
                                  "--prediction",str(folder/"prediction.json")],
                                 capture_output=True,text=True,timeout=60)
            import re
            parsed = {}
            for name,key in (("Macro-F1","macro_f1"),("Micro-F1","micro_f1"),("Subset Accuracy","subset_accuracy")):
                match = re.search(re.escape(name)+r"\s*:\s*([0-9.eE+-]+)",run.stdout,re.I)
                if match:
                    parsed[key] = float(match.group(1))
            agreed = len(parsed)==3 and all(abs(v-result["internal_metrics"][k])<1e-5 for k,v in parsed.items())
            result.update(official_status="passed_smoke_case" if run.returncode==0 and agreed else "review_needed",
                          official_evaluator_path=str(path),official_sha256=sha256(path),
                          official_metrics=parsed,stdout=run.stdout[-3000:],stderr=run.stderr[-1500:],
                          returncode=run.returncode)
        except Exception as exc:
            result.update(official_status="review_needed",error=safe_error(exc))
    write_json(root/"reports"/"evaluator_check.json",result)
    return result


def _run_worker(arguments,log_path,timeout):
    stream = open(log_path,"w",encoding="utf-8")
    process = subprocess.Popen(arguments,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                               text=True,bufsize=1,cwd=SOURCE_DIR)
    messages = queue.Queue()
    def read_lines():
        for line in process.stdout:
            messages.put(line)
        messages.put(None)
    reader = threading.Thread(target=read_lines,daemon=True)
    reader.start()
    start = time.monotonic()
    ended = False
    try:
        while not ended or process.poll() is None:
            if time.monotonic()-start > timeout:
                process.kill()
                process.wait()
                return {"returncode":process.returncode,"timed_out":True}
            try:
                line = messages.get(timeout=1)
            except queue.Empty:
                continue
            if line is None:
                ended = True
            else:
                print(line,end="",flush=True)
                stream.write(line)
                stream.flush()
        return {"returncode":process.wait(),"timed_out":False}
    except KeyboardInterrupt:
        process.kill()
        process.wait()
        raise
    finally:
        stream.close()


def run_model_checks(config):
    import torch
    root = Path(config["project_root"])
    records = read_json(root/"metadata"/"phase1_inputs.json")
    tokenizer = read_json(root/"reports"/"tokenizer.json")
    folder = root/"reports"/"models"
    folder.mkdir(parents=True,exist_ok=True)
    logs = root/"logs"
    logs.mkdir(exist_ok=True)
    source_identity = {p.name:sha256(p) for p in SOURCE_DIR.glob("*.py")}
    environment = {"torch":torch.__version__,"cuda":torch.version.cuda,
                   "gpus":[torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())]}
    for architecture in config["architectures"]:
        request = {k:config[k] for k in ("seed","deduplicate_training","total_tokens","overlap","max_chunks","policy",
                    "amp","require_two_gpus","train_batch_cases","target_effective_cases","benchmark_updates",
                    "temporary_steps","target_training_hours","model_settings")}
        request.update(project_root=str(root),architecture=architecture,
                       checkpoint_path=records[architecture]["path"],
                       checkpoint_sha256=records[architecture]["sha256"],
                       tokenizer_signature=tokenizer["signature"],source_identity=source_identity,
                       cache_fingerprint=read_json(root/"prepared"/"cache"/"manifest.json")["fingerprint"],
                       training_selection=read_json(root/"reports"/"training_selection.json")["fingerprint"],
                       label_vocabulary_sha256=sha256(root/"reports"/"label_vocabulary.json"),
                       loss_settings_sha256=sha256(root/"reports"/"loss_settings.json"),
                       environment=environment)
        request["request_fingerprint"] = digest(request)
        report_path = folder/(architecture+".json")
        if report_path.exists():
            previous = read_json(report_path)
            if previous.get("request_fingerprint")==request["request_fingerprint"] and previous.get("status")=="passed":
                print("Reusing matching completed probe:",architecture,flush=True)
                continue
            history = folder/"history"
            history.mkdir(exist_ok=True)
            previous_id = previous.get("request_fingerprint","unknown")[:16]
            write_json(history/(architecture+"_"+previous_id+".json"),previous)
        request_path = folder/(architecture+"_request.json")
        write_json(request_path,request)
        write_json(report_path,{"architecture":architecture,"status":"running",
                                "request_fingerprint":request["request_fingerprint"]})
        print("\nModel probe:",architecture,flush=True)
        result = _run_worker([sys.executable,"-u",str(SOURCE_DIR/"lsi_probe.py"),
                              "--config",str(request_path),"--report",str(report_path)],
                             logs/(architecture+"_probe.log"),config["probe_timeout_seconds"])
        current = read_json(report_path) if report_path.exists() else {}
        if (result["timed_out"] or current.get("request_fingerprint")!=request["request_fingerprint"]
                or current.get("status")=="running"):
            write_json(report_path,{"architecture":architecture,"status":"timed_out" if result["timed_out"] else "failed",
                                   "request_fingerprint":request["request_fingerprint"],
                                   "returncode":result["returncode"],"log":str(logs/(architecture+"_probe.log"))})
        elif result["returncode"]!=0:
            if current.get("status")!="failed":
                current.update(status="failed",error="Probe process exited with a nonzero status.",
                               returncode=result["returncode"])
                write_json(report_path,current)
            print("Probe failed; details retained. Continuing to the next architecture.",flush=True)
    return model_summary(config)


def model_summary(config):
    folder = Path(config["project_root"])/"reports"/"models"
    result = []
    for architecture in config["architectures"]:
        path = folder/(architecture+".json")
        if not path.exists():
            result.append({"architecture":architecture,"status":"not_run"})
            continue
        report = read_json(path)
        row = {"architecture":architecture,"status":report["status"]}
        if "timing" in report:
            row.update(total_parameters=report["parameters"]["total_parameters"],
                       trainable_parameters=report["parameters"]["trainable_parameters"],
                       physical_batch=report["timing"]["physical_batch"],
                       accumulation=report["timing"]["accumulation_steps"],
                       seconds_per_update=report["timing"]["median_seconds_per_update"],
                       **report["estimates"])
        else:
            row["detail"] = report.get("error",report.get("log",""))
        result.append(row)
    frame = pd.DataFrame(result)
    frame.to_csv(Path(config["project_root"])/"reports"/"model_timing_summary.csv",index=False)
    return frame


def budget_records(config):
    root = Path(config["project_root"])
    summary = model_summary(config)
    proposals = {}
    for row in summary.to_dict("records"):
        if row["status"]!="passed":
            continue
        arch = row["architecture"]
        epochs = min(config.get("max_planned_epochs",10),
                     max(1,math.floor(row["epochs_in_target_budget_with_two_validations_per_epoch"])))
        proposals[arch] = {"architecture":arch,"max_run_hours":5.0,
             "target_training_hours":config["target_training_hours"],"epochs":epochs,
             "schedule_epochs_fixed_at_launch":True,"minimum_epochs":min(2,epochs),"patience":2,
             "seed":config["seed"],"train_batch_cases":int(row["physical_batch"]),
             "accumulation_steps":int(row["accumulation"]),"head_lr":1e-4,
             "backbone_lr":{"decoder":5e-6,"encoder_decoder":1e-4,"prefix":1e-4,"efficient":1e-5}[arch],
             "use_ema":True,"ema_decay":.98,"weight_decay":.01,"gradient_clip":1.,
             "warmup_fraction":.10,"min_lr_fraction":.01,"selection_metric":"macro_f1",
             "model_settings":config["model_settings"],
             "geometry":{k:config[k] for k in ("total_tokens","overlap","max_chunks","policy")},
             "status":"proposal_from_timing_not_a_completed_training_run",
             "less_than_one_epoch_in_target_budget":row["epochs_in_target_budget_with_two_validations_per_epoch"]<1,
             "note":"Review label audit/evaluator before training. Timing excludes setup, saving and teacher-cache export."}
    write_json(root/"reports"/"proposed_training_configs.json",proposals)
    return proposals


def export_outputs(config):
    root = Path(config["project_root"])
    proposals = budget_records(config)
    output = root.parent
    cache_zip = output/"phase5_lsi_prepared_data.zip"
    diagnostics_zip = output/"phase5_lsi_preparation_diagnostics.zip"
    cache_files = [root/"prepared"/"cache"/n for n in ("token_ids.bin","offsets.npy","index.json","manifest.json")]
    cache_files += [root/"reports"/n for n in ("label_vocabulary.json","loss_settings.json","training_selection.json","tokenizer.json",
                    "data_audit.json","label_frequencies.csv","reference_baselines.csv","token_lengths.csv","chunk_policy_coverage.csv")]
    cache_files += [root/"metadata"/n for n in ("data_manifest.json","prepared_protocol.json")]
    signature = digest({str(p.relative_to(root)):sha256(p) for p in cache_files})
    signature_file = root/"metadata"/"exported_cache_signature.json"
    old = read_json(signature_file) if signature_file.exists() else {}
    if not cache_zip.exists() or old.get("signature")!=signature:
        print("Packing reusable LSI data:",cache_zip,flush=True)
        temporary = cache_zip.with_suffix(".zip.tmp")
        with zipfile.ZipFile(temporary,"w",zipfile.ZIP_DEFLATED,compresslevel=1) as archive:
            for p in cache_files:
                archive.write(p,"phase5_lsi_prepared/"+str(p.relative_to(root)))
        temporary.replace(cache_zip)
        write_json(signature_file,{"signature":signature,"archive":str(cache_zip)})
    status = {"data_ready":(root/"prepared"/"cache"/"manifest.json").is_file(),
              "model_probe_status":model_summary(config)[["architecture","status"]].to_dict("records"),
              "official_evaluator_status":read_json(root/"reports"/"evaluator_check.json")["official_status"]
                  if (root/"reports"/"evaluator_check.json").exists() else "not_checked",
              "submission_count_planned":4,"training_started":False,
              "prepared_data_zip":str(cache_zip),"diagnostics_zip":str(diagnostics_zip)}
    write_json(root/"reports"/"preparation_status.json",status)
    print("Packing preparation diagnostics:",diagnostics_zip,flush=True)
    temporary = diagnostics_zip.with_suffix(".zip.tmp")
    with zipfile.ZipFile(temporary,"w",zipfile.ZIP_DEFLATED) as archive:
        for name in ("README.md","SOURCES.md","local_validation.json"):
            if (root/name).is_file():
                archive.write(root/name,"phase5_lsi_preparation/"+name)
        for directory in ("reports","metadata","logs","src","configs"):
            folder = root/directory
            if folder.exists():
                for p in sorted(folder.rglob("*")):
                    if p.is_file() and "__pycache__" not in p.parts and not p.name.endswith(".tmp"):
                        archive.write(p,"phase5_lsi_preparation/"+str(p.relative_to(root)))
    temporary.replace(diagnostics_zip)
    write_json(root/"preparation_status.json",status)
    return status

