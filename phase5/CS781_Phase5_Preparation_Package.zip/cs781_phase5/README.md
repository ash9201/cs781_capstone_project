# CS781 Phase 5 — LSI preparation

This project prepares the official Legal Statute Identification data and measures the cost of the four Phase 1-derived adaptation paths. The notebook is the experiment record; reusable data/model/probe functions are in src/.

## Run on Kaggle

1. Import CS781_Phase5_Preparation_and_Timing.ipynb.
2. Upload CS781_Phase5_Preparation_Package.zip as a Kaggle dataset and attach it. Kaggle may extract this ZIP; that is supported.
3. Attach the original prep-2 tokenizer and the four original Phase 1 checkpoint datasets:
   - decoder_004_mixed217m
   - encdec_002_mixed217m_stable
   - prefix_001_mixed217m
   - efficient_002_mixed217m_500m
4. Enable Internet and access to the existing HF_TOKEN secret for the gated official LSI download.
5. Select GPU T4 x2 and run the notebook in order.

The run identifiers describe the expected original checkpoints. The recorded hashes verify their bytes. A trained Phase 4 task backup is a different input.

Automatic input discovery handles the usual expanded Kaggle datasets. Exact paths can be entered in the settings cell if multiple matching originals are attached.

## Optional inputs

LOCAL_LSI_INPUT accepts an LSI-only ZIP or a folder containing Train/train.json, Train/dev.json and Test/test.json.

PREPARED_INPUT accepts the exported Phase 5 prepared-data ZIP or its extracted phase5_lsi_prepared folder. Matching attached preparations are also discovered automatically. Reuse avoids downloading the raw task JSON and tokenizing it again.

LABEL_VOCAB_INPUT accepts an official list of statute IDs, a dictionary containing label_ids, or an integer-ID-to-name dictionary. Without this input, train/dev-observed IDs form a provisional vocabulary. Internal columns are contiguous even if official IDs are sparse.

EVALUATOR_INPUT accepts the supplied evaluate_phase5.py. If it is attached under that exact filename, it is discovered automatically. The internal evaluator uses the saved label columns. Official label-dimension agreement is recorded as pending when the evaluator is missing.

## Resource controls

RUN_GPU_CHECKS=False performs data preparation without architecture/GPU probes. It does not report model checks as passed.

STAGE_CHECKPOINTS=True copies the four large checkpoint files sequentially to working storage while checking their hashes. This uses approximately 3.5 GB. Setting it to False retains the mounted paths and verifies them without keeping local copies.

The default probe budget is 600 seconds per architecture. Checks run in independent processes and retain logs/status if one times out or fails. Timing includes a maximum-shape memory check, one representative warm-up update and three measured accumulated updates.

The training proposals target 3.5 hours and retain max_run_hours=5. They are not training runs. They exclude setup, saving and teacher-cache export costs. The efficient timing measures the compact student; genuine teacher-cache generation comes later.

## Outputs

- /kaggle/working/phase5_lsi_prepared_data.zip: packed content-token array, offsets, row/label identities and preparation reports.
- /kaggle/working/phase5_lsi_preparation_diagnostics.zip: audits, source/config snapshots, correctness results, per-model logs, timing and proposed configurations.
- /kaggle/working/cs781_phase5: working project and resumable preparation state.

The prepared ZIP contains a handful of packed files rather than a separate NPZ per case. Both output archives are downloadable in the final cell. Keep the prepared data for the training sessions and inspect the smaller diagnostics archive before selecting training settings.

Tokenization commits completed rows and can resume after interruption. Model probes do not export trained weights. The original Phase 1 checkpoints and tokenizer remain separate required artifacts.

## Implementation

LSI uses multi-hot targets and independent sigmoid probabilities. The head aggregates Transformer chunk representations through a BiGRU and label-wise attention. The adaptation paths are two upper decoder blocks, encoder–decoder bottleneck adapters/layer norms, prefix LoRMA+, and a three-block efficient-derived student.

Training-row deduplication uses the original case ID, exact text hash and label set. Development multiplicity is preserved. Data leakage checks report overlaps rather than editing official evaluation splits.

CPU fixture validation is recorded in local_validation.json. It does not establish full-size GPU throughput or task accuracy. The notebook measures those model mechanics and resource costs on the attached checkpoints in the actual session.

Sources and implementation provenance are in SOURCES.md.

